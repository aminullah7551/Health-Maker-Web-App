<?php

namespace AkkaCKEditor\Controller;

use App\Controller\AppController as BaseController;

class AppController extends BaseController
{
}
